
# Importing Data -------------------------------------------------------------
rm(list = ls()) # Remove all variable
datRain <- read.csv("./data.rain.csv")
datFlow <- read.csv("./data.flow.csv")

class(datRain) # checking class
class(datFlow) # checking class

# Exporting Data ----------------------------------------------------------

dat <- cbind(datRain, datFlow[,2]) # binding data
names(dat)[3] <- paste("OutFlow.cm") # changing column names of a data frame
write.csv(dat, "./rr.unified.csv", row.names=F) # save as a new csv file without row names

# Information of Data -----------------------------------------------------

dat.info <- list(name="Hydrological data",
                 unit.time="hour",
                 unit.rain="cm",
                 unit.flow="cm",
                 n.time=nrow(dat),
                 n.rainyDay=0,
                 rain.sum=colSums(dat)[2],
                 rain.mean=colMeans(dat)[2],
                 rain.peak=sapply(dat, max)[2],
                 flow.sum.noBase=0,
                 flow.sum=colSums(dat)[3],
                 flow.peak=sapply(dat, max)[3],
                 flow.baseFlow=(dat[1, 3]+dat[nrow(dat), 3])/2 # Finding discharge
                 )
names(dat.info)

# Count the rainy day ---------------------------------------------------------
for(i in 1:dat.info$n.time){    
    if(dat[i,2]!=0){
        dat.info$n.rainyDay <-dat.info$n.rainyDay+1
    }
}

# Removing base flow from discharge ---------------------------------------
i <- 1
while(i<=dat.info$n.time){
    dat$flowWithoutBase[i]<-dat$OutFlow.cm[i]-dat.info$flow.baseFlow
    if(dat$flowWithoutBase[i]<0){
        dat$flowWithoutBase[i]<-0
    }
    i <- i+1
}

dat.info$flow.sum.noBase <-colSums(dat)[4] # Sum of flow without base flow


# Delete attribute names of list -------------------------------------------

for(i in 1:length(dat.info)){
    attr(dat.info[[i]], "names")=NULL
}


# Exporting data information ----------------------------------------------

datInfoEle <- unlist(dat.info) # character
datInfoName <- names(datInfoEle) # extract name value
datInfoVal <- paste(datInfoName, datInfoEle ) # combine two value
write.table(datInfoVal, "./data.info.txt", row.names = FALSE, col.names = FALSE, quote = FALSE)


